import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-yourcomponent',
  templateUrl: './yourcomponent.component.html',
  styleUrls: ['./yourcomponent.component.css']
})
export class YourcomponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
