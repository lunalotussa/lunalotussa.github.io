export interface Kontak {
    firstName: string;
    lastName: string;
    phone: string;
  }
  
  export const KONTAK = [
    { firstName: "Roosevelt", lastName: "Theo", phone: "+9744445555" },
    { firstName: "Lincoln", lastName: "Abe", phone: "+977772222" },
    { firstName: "Tesla", lastName: "Nico", phone: "+9799991111" },
    { firstName: "Soedirman", lastName: "Jenderal", phone: "+9762621717" }
  ];
  