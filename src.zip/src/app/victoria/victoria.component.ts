import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-victoria',
  templateUrl: './victoria.component.html',
  styleUrls: ['./victoria.component.css']
})
export class VictoriaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
